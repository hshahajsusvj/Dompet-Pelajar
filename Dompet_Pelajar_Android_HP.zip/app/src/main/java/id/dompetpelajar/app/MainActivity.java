package id.dompetpelajar.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int GREEN = Color.rgb(22, 135, 89);
    final int DARK = Color.rgb(31, 41, 55);
    final String[] categories = {"Jajan/makan", "Minum", "Uang kas", "Poe", "Parkir", "Bensin"};
    final int[] planned = {7000, 3000, 1000, 1000, 2000, 1000};
    SharedPreferences prefs;
    JSONArray entries;
    LinearLayout root, list;
    TextView balance, spentView, dateView;
    int budget = 15000;

    String today() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    String rupiah(int n) { return "Rp" + String.format(new Locale("id", "ID"), "%,d", n).replace(',', '.'); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("dompet", MODE_PRIVATE);
        try { entries = new JSONArray(prefs.getString("entries", "[]")); }
        catch(Exception e) { entries = new JSONArray(); }
        build();
        refresh();
    }

    void save() { prefs.edit().putString("entries", entries.toString()).apply(); }

    void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 36, 36, 36);
        root.setBackgroundColor(Color.rgb(247, 249, 248));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("Dompet Pelajar", 28, GREEN, true);
        root.addView(title);
        dateView = text("", 14, Color.GRAY, false);
        root.addView(dateView);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(28, 26, 28, 26);
        card.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 28, 0, 20);
        root.addView(card, cp);
        card.addView(text("SISA UANG HARI INI", 12, Color.GRAY, true));
        balance = text(rupiah(budget), 32, GREEN, true);
        card.addView(balance);
        spentView = text("Terpakai: Rp0 dari Rp15.000", 14, DARK, false);
        card.addView(spentView);

        root.addView(text("Tambah pengeluaran", 20, DARK, true));
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories);
        spinner.setAdapter(adapter);
        root.addView(spinner);

        EditText amount = new EditText(this);
        amount.setHint("Jumlah (contoh: 5000)");
        amount.setInputType(2);
        root.addView(amount);

        EditText note = new EditText(this);
        note.setHint("Keterangan (opsional)");
        root.addView(note);

        Button add = new Button(this);
        add.setText("Catat pengeluaran");
        add.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));
        add.setTextColor(Color.WHITE);
        root.addView(add);
        add.setOnClickListener(v -> {
            String raw = amount.getText().toString().trim();
            if (raw.isEmpty() || Integer.parseInt(raw) <= 0) {
                Toast.makeText(this, "Masukkan jumlah yang benar", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                JSONObject item = new JSONObject();
                item.put("date", today());
                item.put("category", spinner.getSelectedItem().toString());
                item.put("amount", Integer.parseInt(raw));
                item.put("note", note.getText().toString().trim());
                entries.put(item);
                save();
                amount.setText("");
                note.setText("");
                refresh();
                Toast.makeText(this, "Pengeluaran tersimpan", Toast.LENGTH_SHORT).show();
            } catch(Exception e) { Toast.makeText(this, "Gagal menyimpan", Toast.LENGTH_SHORT).show(); }
        });

        TextView budgetTitle = text("Anggaran harian", 20, DARK, true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.setMargins(0, 28, 0, 8);
        root.addView(budgetTitle, bp);
        for (int i=0;i<categories.length;i++) {
            TextView row = text(categories[i] + "  •  " + rupiah(planned[i]), 15, DARK, false);
            row.setPadding(0, 9, 0, 9);
            root.addView(row);
        }

        root.addView(text("Riwayat hari ini", 20, DARK, true));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Button history = new Button(this);
        history.setText("Lihat rekap 7 hari terakhir");
        root.addView(history);
        history.setOnClickListener(v -> showWeekly());

        Button clear = new Button(this);
        clear.setText("Hapus catatan hari ini");
        root.addView(clear);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Hapus catatan hari ini?")
            .setMessage("Catatan tanggal hari ini akan dihapus.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus", (d,w) -> {
                JSONArray kept = new JSONArray();
                for(int i=0;i<entries.length();i++) {
                    JSONObject x = entries.optJSONObject(i);
                    if(x != null && !today().equals(x.optString("date"))) kept.put(x);
                }
                entries = kept; save(); refresh();
            }).show());
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 5, 0, 5);
        return t;
    }

    int totalFor(String date) {
        int sum=0;
        for(int i=0;i<entries.length();i++) {
            JSONObject x=entries.optJSONObject(i);
            if(x!=null && date.equals(x.optString("date"))) sum += x.optInt("amount");
        }
        return sum;
    }

    void refresh() {
        int total = totalFor(today());
        balance.setText(rupiah(budget-total));
        balance.setTextColor(total>budget ? Color.RED : GREEN);
        spentView.setText("Terpakai: " + rupiah(total) + " dari " + rupiah(budget));
        dateView.setText(new SimpleDateFormat("EEEE, dd MMMM yyyy", new Locale("id","ID")).format(new Date()));
        list.removeAllViews();
        boolean found=false;
        for(int i=entries.length()-1;i>=0;i--) {
            JSONObject x=entries.optJSONObject(i);
            if(x!=null && today().equals(x.optString("date"))) {
                found=true;
                String desc=x.optString("category") + (x.optString("note").isEmpty() ? "" : " — "+x.optString("note"));
                TextView row=text(desc+"\n-"+rupiah(x.optInt("amount")),16,DARK,false);
                row.setPadding(0,12,0,12);
                list.addView(row);
                View line=new View(this); line.setBackgroundColor(Color.LTGRAY);
                list.addView(line,new LinearLayout.LayoutParams(-1,1));
            }
        }
        if(!found) list.addView(text("Belum ada pengeluaran hari ini.",14,Color.GRAY,false));
    }

    void showWeekly() {
        StringBuilder s=new StringBuilder();
        Calendar c=Calendar.getInstance();
        int grand=0;
        for(int i=0;i<7;i++) {
            String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
            int n=totalFor(d); grand+=n;
            String label=new SimpleDateFormat("EEE, dd MMM",new Locale("id","ID")).format(c.getTime());
            s.append(label).append(": ").append(rupiah(n)).append("\n");
            c.add(Calendar.DAY_OF_YEAR,-1);
        }
        s.append("\nTotal 7 hari: ").append(rupiah(grand));
        new AlertDialog.Builder(this).setTitle("Rekap 7 hari terakhir")
            .setMessage(s.toString()).setPositiveButton("Tutup",null).show();
    }
}
